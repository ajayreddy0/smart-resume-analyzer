# Smart Resume Analyzer

A web app that analyzes resumes against job descriptions using keyword matching and NLP, built with Streamlit.

## 🔧 Features
- Upload PDF resumes
- Text extraction using `PyPDF2`
- Text cleaning and keyword matching
- Streamlit UI for displaying results

## 🚀 How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   python -m spacy download en_core_web_sm
   ```

2. Run the app:
   ```bash
   streamlit run app.py
   ```

## 🌐 Deployment
Deploy this app for free on [Streamlit Cloud](https://streamlit.io/cloud).

---
Created by Ajay
